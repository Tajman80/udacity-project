# (Loan Data From Prosper)
## by (Sulyman Ahmed)


## Dataset

> This data set contains 113,937 loans with 81 variables on each loan, including loan amount, Credit score range, current loan status, borrower income, and many others.
>  [ All column information](https://docs.google.com/spreadsheets/d/1gDyi_L4UvIrLTEC6Wri5nbaMmkGmLQBk-Yx3z0XDEtI/edit#gid=0)

## Preliminary Wrangling
Out of the 81 columns I choosed the data set I would focus on into a data fram which includes
* Term: The length of the loan expressed in months.	
* LoanStatus: The current status of the loan: Cancelled,  Chargedoff, Completed, Current, Defaulted, FinalPaymentInProgress, PastDue. The PastDue status will be accompanied by a delinquency bucket.
* EmploymentStatus:The employment status of the borrower at the time they posted the listing.
* IsBorrowerHomeowner: A Borrower will be classified as a homowner if they have a mortgage on their credit profile or provide documentation confirming they are a homeowner.
* LoanOriginalAmount: The origination amount of the loan.
* Listing_category: The category of the listing that the borrower selected when posting their listing
* CreditScoreRangeLower: The lower value representing the range of the borrower's credit score as provided by a consumer credit rating agency.
* CreditScoreRangeUpper: The upper value representing the range of the borrower's credit score as provided by a consumer credit rating agency. 
* StatedMonthlyIncome: The monthly income the borrower stated at the time the listing was created.

#### Wrangling
* Replaced NaN in EmploymentStatus with Not available and drop NaN value in CreditScoreRangeLower and CreditScoreRangeUpper
* Converted CreditScoreRangeLower, CreditScoreRangeUpper to one column and then have its score regard to format as follows:
> Poor: 300 - 549,
> Fair: 550 - 649,
> Good: 650 -749,
> Excellent: 750 - 900
* Created a better representation of the Listing category

## Summary of Findings

### Univariate Exploration
In the exploration i found the following:

* Most of the borrowers loans term is for 3 years then 5 years and 1 year.
* Credit score for borrowers seems good most of them in the 'Good' score followed by 'Fair'
* The employment status distribution depict majority of individuals that applied for the loans are employed and the least being retired individuals.
* The homeowners distribution was evenly distributed in the population.
* Large numbers of the borrowers are of the high income range earners.
* Using the log scale, the borrowers who are currently on the loan plan are the highest, followed by those who have completed the loan
* Majority of the loan was collected for debt consolidation.
* Most of the monthly income for the borrowers is in the range 2000 to 6000

### Bivariate Exploration
* Using a boxplot to get the relation between LoanStatus and [StatedMonthlyIncome, MonthlyLoanPayment, LoanOriginalAmount], it depict that there is a negative correlation between monthly income and Loan status borrowers that passed their due date have a lower income but that is true from past due 1-15 days and borrowers that passed their due date > 120 days have a short distribution in monthly income and there is a slightly positive correlation that borrowers that pass their due data ask for a higher loan amount.
* taking a scatter plot of the same relation as above, it depicts that there is an approximately positive linear ralation between Monthly loan amount and Loan original amount and not a big correlation between monthly income and monthly loan payment
* using clusterd bar chart to show the 3 years is the highest terms for loan collected, followed by 5 years. Only a few borrowers collected loans for one year. They are employed and have good in credit score
* Also, there is no high interaction between term and monthly income, in normal higher in term lower in loan monthly payment. But the violinplot shows that borrowers that loan for 5 years pay much every month and this because that these borrowers make a high Loan amount and it makes sense. There is a linear correlation in CreditScore and other numeric features and with poor credit scores borrowers pay less each month because they ask for low amounts and borrowers that are not employed have a lower monthly income

### Multivariate Exploration

* Showing how the three numerical attribute play into the relationship between loan status and loan terms, It is clearly seen that the lower the monthly income, the longer the repayment delay. In all cases, the larger the monthly loan payment of loans when the loan is for one year. When the loan is of high amount, the monthly payment of the loan is large and the monthly income is low, The delay in repayment often occurs. 
Most borrowers who need a loan of high amount make it for 5 Years

## Key Insights for Presentation

> The multiviriate exploration shows that the lower the monthly income, the longer the repayment delay.